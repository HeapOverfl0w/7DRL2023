//Damage Types
LIGHTNING = 0;
FIRE = 1;
BLUNT = 2;
SLASH = 3;